# SD-Planer für iPhone

Diese iOS-App verpackt die vorhandene SD-Planer-Aufnahme in eine installierbare
iPhone-App. Die Formulare, Fotos und Entwürfe bleiben lokal auf dem Gerät.
Fotos können über die iPhone-Kamera oder die Fotomediathek hinzugefügt werden.
Aufträge lassen sich über das iOS-Teilen-Menü sichern und aus der Dateien-App
wieder importieren.

## Projekt lokal starten

Benötigt werden Node.js und npm:

```sh
npm install
npx expo start
```

Zum Erstellen eines iOS-Builds auf einem Mac Xcode verwenden. Alternativ kann
der Build mit Expo EAS in der Cloud erstellt werden; dafür wird ein Expo-Konto
benötigt:

```sh
npx eas-cli login
npx eas-cli init
npx eas-cli build --platform ios --profile preview
```

Ein interner iPhone-Installationsbuild benötigt ein Apple-Developer-Konto und
die Registrierung des Testgeräts. Für TestFlight wird ein Produktionsbuild
benötigt:

```sh
npx eas-cli build --platform ios --profile production
npx eas-cli submit --platform ios --latest
```

Apple verlangt für TestFlight und den App Store ein aktives Apple-Developer-
Program-Konto. Die Bundle-ID in `app.json` muss zu diesem Apple-Konto passen,
bevor der erste Build erstellt wird. Dieses Repository enthält den App-
Quellcode; ein signierter iPhone-Build oder eine App-Store-Veröffentlichung
kann ohne Apple-Konto und Signierung nicht hier erzeugt werden.
